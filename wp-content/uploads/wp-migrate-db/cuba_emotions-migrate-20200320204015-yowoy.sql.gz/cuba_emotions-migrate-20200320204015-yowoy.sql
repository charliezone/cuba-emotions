# WordPress MySQL database migration
#
# Generated: Friday 20. March 2020 20:40 UTC
# Hostname: localhost
# Database: `cuba_emotions`
# URL: //localhost/cuba-emotions
# Path: C:\\xampp\\htdocs\\cuba-emotions
# Tables: wp_admin_columns, wp_commentmeta, wp_comments, wp_db7_forms, wp_duplicator_packages, wp_layerslider, wp_layerslider_revisions, wp_links, wp_mailpoet_custom_fields, wp_mailpoet_dynamic_segment_filters, wp_mailpoet_feature_flags, wp_mailpoet_forms, wp_mailpoet_log, wp_mailpoet_mapping_to_external_entities, wp_mailpoet_newsletter_links, wp_mailpoet_newsletter_option, wp_mailpoet_newsletter_option_fields, wp_mailpoet_newsletter_posts, wp_mailpoet_newsletter_segment, wp_mailpoet_newsletter_templates, wp_mailpoet_newsletters, wp_mailpoet_scheduled_task_subscribers, wp_mailpoet_scheduled_tasks, wp_mailpoet_segments, wp_mailpoet_sending_queues, wp_mailpoet_settings, wp_mailpoet_statistics_clicks, wp_mailpoet_statistics_forms, wp_mailpoet_statistics_newsletters, wp_mailpoet_statistics_opens, wp_mailpoet_statistics_unsubscribes, wp_mailpoet_statistics_woocommerce_purchases, wp_mailpoet_stats_notifications, wp_mailpoet_subscriber_custom_field, wp_mailpoet_subscriber_ips, wp_mailpoet_subscriber_segment, wp_mailpoet_subscribers, wp_mailpoet_user_flags, wp_options, wp_postmeta, wp_posts, wp_revslider_css, wp_revslider_layer_animations, wp_revslider_navigations, wp_revslider_sliders, wp_revslider_slides, wp_revslider_static_slides, wp_sbi_instagram_feeds_posts, wp_sbi_instagram_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, cmsmasters_like, content_template, event, mailpoet_page, nav_menu_item, page, post, profile, project, wpcf7_contact_form, wplp-news-widget
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_admin_columns`
#

DROP TABLE IF EXISTS `wp_admin_columns`;


#
# Table structure of table `wp_admin_columns`
#

CREATE TABLE `wp_admin_columns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `list_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `columns` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `list_id` (`list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_admin_columns`
#
INSERT INTO `wp_admin_columns` ( `id`, `list_id`, `list_key`, `title`, `columns`, `settings`, `date_created`, `date_modified`) VALUES
(1, '5e751c78059cb', 'profile', 'Profiles', 'a:5:{s:5:"title";a:4:{s:4:"type";s:5:"title";s:5:"label";s:5:"Title";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";}s:9:"pl_avatar";a:4:{s:4:"type";s:9:"pl_avatar";s:5:"label";s:6:"Avatar";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";}s:9:"pl_categs";a:4:{s:4:"type";s:9:"pl_categs";s:5:"label";s:10:"Categories";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";}s:8:"comments";a:4:{s:4:"type";s:8:"comments";s:5:"label";s:82:"<span class="vers"><div title="Comments" class="comment-grey-bubble"></div></span>";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";}s:10:"menu_order";a:4:{s:4:"type";s:10:"menu_order";s:5:"label";s:84:"<span class="vers"><div class="dashicons dashicons-sort" title="Order"></div></span>";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";}}', 'a:0:{}', '2020-03-20 19:41:54', '2020-03-20 19:41:54') ;

#
# End of data contents of table `wp_admin_columns`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2020-03-07 16:15:13', '2020-03-07 16:15:13', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_db7_forms`
#

DROP TABLE IF EXISTS `wp_db7_forms`;


#
# Table structure of table `wp_db7_forms`
#

CREATE TABLE `wp_db7_forms` (
  `form_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `form_post_id` bigint(20) NOT NULL,
  `form_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_db7_forms`
#
INSERT INTO `wp_db7_forms` ( `form_id`, `form_post_id`, `form_value`, `form_date`) VALUES
(1, 6, 'a:6:{s:12:"cfdb7_status";s:4:"read";s:9:"your-name";s:13:"Carlos Rafael";s:12:"phone-number";s:10:"4456456456";s:10:"your-email";s:16:"carlos@gmail.com";s:4:"type";a:1:{i:0;s:10:"Influencer";}s:15:"upload-file-627";a:1:{i:0;s:81:"http://localhost/cuba-emotions/wp-content/uploads/wp_dndcf7_uploads/2020/03/1.jpg";}}', '2020-03-17 20:08:17'),
(2, 6, 'a:15:{s:12:"cfdb7_status";s:4:"read";s:4:"type";a:1:{i:0;s:10:"Influencer";}s:9:"full-name";s:12:"Carli Rafael";s:4:"nick";s:5:"carli";s:12:"phone-number";s:9:"456456456";s:10:"your-email";s:16:"carlis@gmail.com";s:9:"date-born";s:0:"";s:6:"height";s:0:"";s:5:"bustt";s:0:"";s:5:"waist";s:0:"";s:4:"hips";s:0:"";s:5:"shoes";s:0:"";s:15:"upload-file-627";a:1:{i:0;s:81:"http://localhost/cuba-emotions/wp-content/uploads/wp_dndcf7_uploads/2020/03/2.jpg";}s:4:"hair";s:0:"";s:4:"eyes";s:0:"";}', '2020-03-18 18:11:32') ;

#
# End of data contents of table `wp_db7_forms`
# --------------------------------------------------------



#
# Delete any existing table `wp_duplicator_packages`
#

DROP TABLE IF EXISTS `wp_duplicator_packages`;


#
# Table structure of table `wp_duplicator_packages`
#

CREATE TABLE `wp_duplicator_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hash` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `package` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `wp_duplicator_packages`
#
